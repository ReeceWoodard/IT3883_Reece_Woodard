# Dictionary with the value of each coin.
coin_values = {
    "pennies": 1,
    "nickels": 5,
    "dimes": 10,
    "quarters": 25
}

# Input
sentence = input("Enter the coin amounts: ")

# Convert the input to lowercase.
sentence = sentence.lower()

# Separate each coin description using the word and.
coin_descriptions = sentence.split(" and ")

# Store the value in cents.
total_cents = 0

# Process each coin description.
for description in coin_descriptions:
    # Remove extra spaces and separate the quantity and denomination.
    parts = description.strip().split()

    quantity = int(parts[0])
    denomination = parts[1]

    # Calculate the value of this group of coins.
    coin_total = quantity * coin_values[denomination]

    # Add the coin value to the total.
    total_cents += coin_total

# Cents to dollars.
dollar_amount = total_cents / 100

# Result with two decimal places.
print(f"Dollar amount: ${dollar_amount:.2f}")

input("Press Enter to exit...")