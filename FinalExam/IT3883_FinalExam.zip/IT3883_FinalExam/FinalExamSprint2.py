# Store every supported singular and plural denomination.
coin_values = {
    "penny": 1,
    "pennies": 1,
    "nickel": 5,
    "nickels": 5,
    "dime": 10,
    "dimes": 10,
    "quarter": 25,
    "quarters": 25
}

# Input
sentence = input("Enter the coin amounts: ").strip().lower()

# Begin the total at zero cents.
total_cents = 0

try:
    # Make sure the user entered something.
    if not sentence:
        raise ValueError("The input cannot be empty.")

    # Separate the groups of coins when and is read.
    coin_descriptions = sentence.split(" and ")

    # Process every coin group.
    for description in coin_descriptions:
        # Remove extra spaces and split the group into words.
        parts = description.strip().split()

        # Each group must have a quantity and denomination.
        if len(parts) != 2:
            raise ValueError(
                f"Invalid coin description: '{description.strip()}'."
            )

        quantity_text = parts[0]
        denomination = parts[1]

        # Convert the quantity from text into an integer.
        quantity = int(quantity_text)

        # Negative amounts of coins are not valid.
        if quantity < 0:
            raise ValueError("Coin quantities cannot be negative.")

        # Make sure the denomination is supported.
        if denomination not in coin_values:
            raise ValueError(
                f"Unknown coin denomination: '{denomination}'."
            )

        # Add group value to the total.
        total_cents += quantity * coin_values[denomination]

    # Convert from cents to dollars.
    dollar_amount = total_cents / 100

    # Display the total with two decimal places.
    print(f"Dollar amount: ${dollar_amount:.2f}")

except ValueError as error:
    # Display a message instead of allowing the program to crash.
    print(f"Input error: {error}")
